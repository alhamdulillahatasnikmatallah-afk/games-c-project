"""Patch otomatis android/ hasil `flutter create` untuk Cend Dolphin."""
import re, pathlib

root = pathlib.Path("android/app")
mf = root / "src/main/AndroidManifest.xml"
s = mf.read_text()

perms = """    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE"/>
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
    <uses-permission android:name="android.permission.RECORD_AUDIO"/>
    <uses-permission android:name="android.permission.CAMERA"/>
    <uses-permission android:name="android.permission.VIBRATE"/>
"""
if "ACCESS_NETWORK_STATE" not in s:
    s = s.replace("<application", perms + "    <application", 1)

s = re.sub(r'android:label="[^"]*"', 'android:label="Cend Dolphin"', s, count=1)
mf.write_text(s)

# minSdk 23 (Groovy / Kotlin DSL)
for name in ("build.gradle", "build.gradle.kts"):
    g = root / name
    if g.exists():
        t = g.read_text()
        t = t.replace("flutter.minSdkVersion", "23")
        t = re.sub(r"(minSdk(?:Version)?\s*=?\s*)\d+", r"\g<1>23", t)
        g.write_text(t)
        print("patched", g)

print("OK manifest patched")
