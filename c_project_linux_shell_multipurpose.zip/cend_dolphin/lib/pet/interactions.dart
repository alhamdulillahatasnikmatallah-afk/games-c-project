import 'dart:async';
import 'dart:math';
import 'package:sensors_plus/sensors_plus.dart';

/// Mendeteksi goyangan HP (shake) dari aliran akselerometer.
class ShakeDetector {
  StreamSubscription? _sub;
  final List<int> _peaks = [];
  int _lastShake = 0;
  final void Function() onShake;
  ShakeDetector(this.onShake);

  void start() {
    try {
      _sub = accelerometerEventStream().listen((e) {
        final g = sqrt(e.x * e.x + e.y * e.y + e.z * e.z);
        final now = DateTime.now().millisecondsSinceEpoch;
        if (g > 18) {
          _peaks.add(now);
          _peaks.removeWhere((t) => now - t > 800);
          if (_peaks.length >= 3 && now - _lastShake > 1500) {
            _lastShake = now;
            _peaks.clear();
            onShake();
          }
        }
      });
    } catch (_) {}
  }

  void stop() {
    _sub?.cancel();
    _sub = null;
  }
}

