import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:cend_dolphin/core/theme.dart';
import 'package:cend_dolphin/core/sound.dart';
import 'package:cend_dolphin/pet/pet_model.dart';
import 'package:cend_dolphin/pet/pet_sprites.dart';
import 'package:cend_dolphin/pet/pixel_painter.dart';
import 'package:cend_dolphin/pet/backgrounds.dart';
import 'package:cend_dolphin/pet/food_dock.dart';
import 'package:cend_dolphin/pet/interactions.dart';
import 'package:cend_dolphin/pet/mic_blow.dart';
import 'package:cend_dolphin/ui/pastel_widgets.dart';
import 'package:cend_dolphin/easter/egg_video.dart';
import 'package:cend_dolphin/tools/tools_home.dart';
import 'package:cend_dolphin/pet/settings_screen.dart';

class PetScreen extends StatefulWidget {
  final PetState state;
  const PetScreen({super.key, required this.state});
  @override
  State<PetScreen> createState() => _PetScreenState();
}

class _PetScreenState extends State<PetScreen> with WidgetsBindingObserver {
  late PetState s = widget.state;
  Expr expr = Expr.normal;
  Expr? _lastExpr;
  Timer? _idleTimer;
  late final ShakeDetector _shake;
  late final MicBlowDetector _mic;
  String bubble = '';
  Timer? _bubbleTimer;
  double _patGauge = 0;
  Offset? _lastPan;
  int _tapCount = 0;
  Timer? _tapResetTimer;
  Timer? _holdTimer5s, _holdTimerWarn;
  double dragScale = 1.0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    s.applyDecay();
    s.greetBack();
    s.bumpStreak();
    PetStore.save(s);
    _shake = ShakeDetector(_onShake)..start();
    _mic = MicBlowDetector(_onBlow);
    _mic.start(); // aman: gagal diam-diam bila izin ditolak
    _scheduleIdle();
    _say(s.kind.greet());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _idleTimer?.cancel();
    _bubbleTimer?.cancel();
    _tapResetTimer?.cancel();
    _holdTimer5s?.cancel();
    _holdTimerWarn?.cancel();
    _shake.stop();
    _mic.stop();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState st) {
    if (st == AppLifecycleState.paused) {
      PetStore.save(s);
      _shake.stop();
    } else if (st == AppLifecycleState.resumed) {
      _shake.start();
    }
  }

  void _scheduleIdle() {
    _idleTimer?.cancel();
    final hour = DateTime.now().hour;
    final sleeping = hour >= 22 || hour < 5;
    _idleTimer = Timer(Duration(seconds: 2 + Random().nextInt(3)), () {
      if (!mounted) return;
      Expr next;
      if (sleeping) {
        next = Expr.sleep;
      } else {
        final pool = [
          Expr.normal,
          Expr.blink,
          Expr.sleepy,
          Expr.bored,
          Expr.sad,
          Expr.laugh,
          Expr.shock,
          Expr.love,
        ];
        pool.removeWhere((e) => e == _lastExpr);
        next = pool[Random().nextInt(pool.length)];
      }
      setState(() {
        expr = next;
        _lastExpr = next;
      });
      _scheduleIdle();
    });
  }

  void _say(String text, {Duration dur = const Duration(seconds: 3)}) {
    _bubbleTimer?.cancel();
    setState(() => bubble = text);
    _bubbleTimer = Timer(dur, () {
      if (mounted) setState(() => bubble = '');
    });
  }

  void _onShake() {
    s.stats['shakes'] = (s.stats['shakes'] ?? 0) + 1;
    s.happy = max(15, s.happy - 5);
    Sfx.i.angry();
    setState(() => expr = Expr.dizzy);
    _say('Puyeng...');
    if (s.stats['shakes']! % 3 == 0) {
      s.sulkUntil = DateTime.now().add(const Duration(seconds: 60));
      _say('Aku ngambek dulu ya.');
    }
    PetStore.save(s);
    Timer(const Duration(seconds: 2), () {
      if (mounted) setState(() => expr = Expr.normal);
    });
  }

  void _onBlow() {
    Sfx.i.happy();
    setState(() => expr = Expr.blink);
    _say('Hihi, geli!');
  }

  void _onTapHead() {
    Sfx.i.click();
    _tapCount++;
    _tapResetTimer?.cancel();
    _tapResetTimer = Timer(const Duration(milliseconds: 900), () => _tapCount = 0);
    if (s.isSulking) {
      _say('Hmph.');
      return;
    }
    if (_tapCount >= 4) {
      setState(() => expr = Expr.shock);
      _say('Hoi, cukup!');
      _tapCount = 0;
    } else {
      setState(() => expr = Expr.blink);
      _say('?');
    }
  }

  void _onPanStart(DragStartDetails d) {
    _patGauge = 0;
    _lastPan = d.localPosition;
  }

  void _onPanUpdate(DragUpdateDetails d) {
    if (s.isSulking) return;
    if (_lastPan != null) {
      _patGauge += (d.localPosition - _lastPan!).distance;
      _lastPan = d.localPosition;
    }
    if (_patGauge > 120) {
      _patGauge = 0;
      s.stats['pats'] = (s.stats['pats'] ?? 0) + 1;
      s.happy = min(100, s.happy + 5);
      s.addXp(1);
      Sfx.i.happy();
      setState(() => expr = Expr.love);
      _say('Enaakk~');
      PetStore.save(s);
    }
  }

  void _holdDown(_) {
    _holdTimerWarn = Timer(const Duration(milliseconds: 4500), () {});
    _holdTimer5s = Timer(const Duration(milliseconds: 5000), _openEgg);
  }

  void _holdUp(_) {
    _holdTimerWarn?.cancel();
    _holdTimer5s?.cancel();
  }

  void _openEgg() {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const EggVideoScreen()));
  }

  void _feed(FoodItem f) {
    if (s.isSulking) {
      _say('Tidak mau!');
      return;
    }
    if (s.hunger > 90) {
      _say('Sudah kenyang~');
      return;
    }
    final isFav = f.label.toLowerCase() == s.kind.favorite.toLowerCase();
    final isDislike = f.label.toLowerCase() == s.kind.dislike.toLowerCase();
    if (isDislike) {
      Sfx.i.error();
      setState(() => expr = Expr.sad);
      _say('Hmm, enggak suka.');
      return;
    }
    Sfx.i.eat();
    s.hunger = min(100, s.hunger + (isFav ? 20 : 10));
    s.addXp(isFav ? 8 : 4);
    s.stats['feeds'] = (s.stats['feeds'] ?? 0) + 1;
    setState(() => expr = isFav ? Expr.love : Expr.laugh);
    _say(isFav ? 'Favoritku! Makasih!' : 'Nyam nyam.');
    PetStore.save(s);
  }

  void _openTools() async {
    s.stats['toolsUsed'] = (s.stats['toolsUsed'] ?? 0) + 1;
    s.addXp(3);
    PetStore.save(s);
    await Navigator.of(context)
        .push(MaterialPageRoute(builder: (_) => const ToolsHomeScreen()));
    if (mounted) setState(() {});
  }

  void _openSettings() async {
    await Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => SettingsScreen(state: s)));
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final pal = paletteFor(s.kind);
    final rows = spriteFor(s.kind, expr);
    return Scaffold(
      backgroundColor: PastelPalette.cream,
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            child: Column(children: [
              Row(children: [
                Expanded(
                  child: Text('${s.name}  •  Lv.${s.level}',
                      style: roundedText(16, PastelPalette.brown, w: FontWeight.w700)),
                ),
                RoundButton(icon: Icons.settings, label: '', onTap: _openSettings),
              ]),
              const SizedBox(height: 6),
              StatBar(label: 'HP', value: s.energy, color: PastelPalette.pink),
              const SizedBox(height: 4),
              StatBar(label: 'Lapar', value: s.hunger, color: PastelPalette.orange),
              const SizedBox(height: 4),
              StatBar(label: 'Senang', value: s.happy, color: PastelPalette.blue),
            ]),
          ),
          Expanded(
            child: Stack(children: [
              Positioned.fill(child: PetBackground(bg: s.background)),
              Center(
                child: SpeechBubble(text: bubble),
              ).withOffset(const Offset(0, -110)),
              Center(
                child: DragTarget<FoodItem>(
                  onAcceptWithDetails: (d) => _feed(d.data),
                  builder: (context, cand, rej) => GestureDetector(
                    onTap: _onTapHead,
                    onPanStart: _onPanStart,
                    onPanUpdate: _onPanUpdate,
                    onTapDown: _holdDown,
                    onTapUp: _holdUp,
                    onTapCancel: () => _holdUp(null),
                    child: AnimatedScale(
                      scale: cand.isNotEmpty ? 1.08 : 1.0,
                      duration: const Duration(milliseconds: 150),
                      child: PixelSprite(rows: rows, palette: pal_to_map(pal), size: 180),
                    ),
                  ),
                ),
              ),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
              RoundButton(icon: Icons.build, label: 'Tools', onTap: _openTools),
              RoundButton(
                  icon: Icons.emoji_events,
                  label: 'Koleksi',
                  onTap: () => _say('Streak: ${s.streak} hari')),
            ]),
          ),
          FoodDock(onFeed: _feed),
          const SizedBox(height: 8),
        ]),
      ),
    );
  }
}

Map<String, Color> pal_to_map(PetPalette p) => {
      'K': p.outline,
      'B': p.body,
      'D': p.bodyDark,
      'A': p.accent,
      'C': p.cheek,
      'E': const Color(0xFF3A2E28),
      'M': const Color(0xFF3A2E28),
      '.': Colors.transparent,
    };

extension on Widget {
  Widget withOffset(Offset o) => Transform.translate(offset: o, child: this);
}
