# C Project — Multipurpose & Network/Security Lab

Flutter Android app adapted from Cend Dolphin. Main tools screen is organized into two sections:

- **Multipurpose:** existing in-app Sensor Lab, Encode & Hash, Network Utilities, Daily Utilities, and Privacy Tools.
- **Network & Security Lab:** interactive PTY-backed Android shell (`/system/bin/sh`) and a shortcut to open Termux.

## Important shell distinction

The in-app terminal launches Android's real `/system/bin/sh` through a pseudo-terminal (PTY). Stock Android does **not** ship GNU Bash or a full Linux distribution, so this is a real Android shell, not a bundled Linux/Bash environment. The **TERMUX BASH** action opens the installed Termux app, where Bash and Linux packages can be installed. Termux must be installed separately. This project does not bundle a complete Linux root filesystem.

## Build

Use the GitHub Actions workflow supplied in the chat as `.github/workflows/build.yml`. It creates the Android platform scaffolding, applies the manifest patch, resolves Flutter packages, and builds a debug APK artifact. The workflow must run successfully before the APK can be called build-verified.

## Status

The source and workflow are prepared, but compilation and on-device PTY behavior have not been executed in this environment. A successful CI build and real-device smoke test are required to verify the result. API integrations for external services (temp mail, news, uploader, AI, manga catalogs, etc.) are not included; the existing utility screens remain the implemented tools.

## Responsible use

Use the shell for your own device and authorized labs. Network modules should be limited to diagnostics and systems you own or have permission to test.
